#ifndef JSON_SERIALIZER_H
#define JSON_SERIALIZER_H

#include <vector>
#include <memory>
#include <string>
#include "Animal.h"

/**
 * JSON Serializer class
 * Handles saving and loading collections of animals to/from JSON files
 */
class JsonSerializer {
public:
    /**
     * Save a collection of animals to a JSON file
     * @param animals - vector of animal shared pointers
     * @param filename - path to output file
     * @return true if successful, false otherwise
     */
    bool saveToFile(const std::vector<std::shared_ptr<Animal>>& animals, const std::string& filename);
    
    /**
     * Load a collection of animals from a JSON file
     * @param filename - path to input file
     * @return vector of animal shared pointers, or nullptr if failed
     */
    std::unique_ptr<std::vector<std::shared_ptr<Animal>>> loadFromFile(const std::string& filename);
};

#endif