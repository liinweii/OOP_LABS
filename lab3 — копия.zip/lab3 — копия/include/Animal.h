#ifndef ANIMAL_H
#define ANIMAL_H

#include <string>
#include <memory>
#include <functional>
#include <unordered_map>
#include <json.hpp>

using json = nlohmann::json;

/**
 * Abstract base class for all animals
 * Provides common attributes and virtual methods for serialization
 * Uses registry pattern for factory - no if-else needed!
 */
class Animal {
protected:
    std::string name;      // Animal's name
    int age;               // Age in years
    double weight;         // Weight in kg
    std::string color;     // Main color

public:
    Animal(const std::string& name = "", int age = 0, double weight = 0.0, const std::string& color = "");
    virtual ~Animal() = default;

    // Getters
    std::string getName() const { return name; }
    int getAge() const { return age; }
    double getWeight() const { return weight; }
    std::string getColor() const { return color; }

    // Setters
    void setName(const std::string& n) { name = n; }
    void setAge(int a) { age = a; }
    void setWeight(double w) { weight = w; }
    void setColor(const std::string& c) { color = c; }

    // Virtual methods for polymorphism
    virtual json toJson() const = 0;           // Serialize to JSON
    virtual void fromJson(const json& j) = 0;  // Deserialize from JSON
    virtual void display() const = 0;          // Display animal info
    virtual std::string getType() const = 0;   // Get animal type name
    virtual void edit() = 0;                   // Interactive editing

    // Registry pattern for factory - no if-else or reflection!
    using Creator = std::function<std::shared_ptr<Animal>(const json&)>;

    static void registerType(const std::string& type, Creator creator);
    static std::shared_ptr<Animal> createFromJson(const json& j);

private:
    static std::unordered_map<std::string, Creator>& getRegistry();
};

#endif