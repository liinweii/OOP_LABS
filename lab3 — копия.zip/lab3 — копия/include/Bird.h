#ifndef BIRD_H
#define BIRD_H

#include "Animal.h"

/**
 * Bird class - inherits from Animal
 * Adds wingspan and canFly status
 */
class Bird : public Animal {
private:
    double wingspan;       // Wingspan in cm
    bool canFly;           // Whether the bird can fly

public:
    Bird(const std::string& name = "", int age = 0, double weight = 0.0,
         const std::string& color = "", double wingspan = 0.0, bool canFly = true);
    Bird(const json& j);
    
    // Getters
    double getWingspan() const { return wingspan; }
    bool getCanFly() const { return canFly; }

    // Setters
    void setWingspan(double ws) { wingspan = ws; }
    void setCanFly(bool fly) { canFly = fly; }

    // Override virtual methods
    json toJson() const override;
    void fromJson(const json& j) override;
    void display() const override;
    std::string getType() const override { return "Bird"; }
    void edit() override;
};

#endif