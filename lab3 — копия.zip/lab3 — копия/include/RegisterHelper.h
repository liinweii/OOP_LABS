#ifndef REGISTER_HELPER_H
#define REGISTER_HELPER_H

#include "Animal.h"

/**
 * Helper template for automatic registration of animal types
 * This eliminates the need for if-else chains when adding new classes
 * 
 * Usage: static RegisterHelper<ClassName> registryName("TypeName");
 * 
 * Adding a new class requires only creating the class files and
 * adding ONE line of registration code - no changes to existing code!
 */
template<typename T>
class RegisterHelper {
public:
    RegisterHelper(const std::string& type) {
        // Automatically register the class with the factory
        Animal::registerType(type, [](const json& j) -> std::shared_ptr<Animal> {
            return std::make_shared<T>(j);
        });
    }
};

#endif