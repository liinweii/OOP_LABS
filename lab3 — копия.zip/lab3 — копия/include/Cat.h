#ifndef CAT_H
#define CAT_H

#include "Animal.h"

/**
 * Cat class - inherits from Animal
 * Adds indoor status and fur length
 */
class Cat : public Animal {
private:
    bool isIndoor;         // Whether cat lives indoors only
    std::string furLength; // Short, medium, long

public:
    Cat(const std::string& name = "", int age = 0, double weight = 0.0,
        const std::string& color = "", bool isIndoor = true, const std::string& furLength = "Short");
    Cat(const json& j);
    
    // Getters
    bool getIsIndoor() const { return isIndoor; }
    std::string getFurLength() const { return furLength; }

    // Setters
    void setIsIndoor(bool indoor) { isIndoor = indoor; }
    void setFurLength(const std::string& length) { furLength = length; }

    // Override virtual methods
    json toJson() const override;
    void fromJson(const json& j) override;
    void display() const override;
    std::string getType() const override { return "Cat"; }
    void edit() override;
};

#endif