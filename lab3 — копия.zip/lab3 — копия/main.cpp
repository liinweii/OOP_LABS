#include <iostream>
#include <vector>
#include <memory>
#include <string>
#include <limits>
#include "Animal.h"
#include "Dog.h"
#include "Cat.h"
#include "Bird.h"
#include "Fish.h"
#include "Hamster.h"
#include "JsonSerializer.h"

class PetManager {
private:
    std::vector<std::shared_ptr<Animal>> pets;
    JsonSerializer serializer;

    void clearInputBuffer() {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

public:
    void addPet() {
        std::cout << "\n=== Add New Pet ===\n";
        std::cout << "Select pet type:\n";
        std::cout << "1. Dog\n2. Cat\n3. Bird\n4. Fish\n5. Hamster\n";
        std::cout << "Choice: ";

        int choice;
        std::cin >> choice;
        clearInputBuffer();

        std::string name, color;
        int age;
        double weight;

        std::cout << "Name: ";
        std::getline(std::cin, name);
        std::cout << "Age (years): ";
        std::cin >> age;
        std::cout << "Weight (kg): ";
        std::cin >> weight;
        std::cout << "Color: ";
        std::cin >> color;

        switch (choice) {
            case 1: {
                std::string breed;
                int trained;
                std::cout << "Breed: ";
                std::cin >> breed;
                std::cout << "Is trained? (1-yes/0-no): ";
                std::cin >> trained;
                pets.push_back(std::make_shared<Dog>(name, age, weight, color, breed, trained == 1));
                break;
            }
            case 2: {
                int indoor;
                std::string furLength;
                std::cout << "Indoor only? (1-yes/0-no): ";
                std::cin >> indoor;
                std::cout << "Fur length (Short/Medium/Long): ";
                std::cin >> furLength;
                pets.push_back(std::make_shared<Cat>(name, age, weight, color, indoor == 1, furLength));
                break;
            }
            case 3: {
                double wingspan;
                int canFly;
                std::cout << "Wingspan (cm): ";
                std::cin >> wingspan;
                std::cout << "Can fly? (1-yes/0-no): ";
                std::cin >> canFly;
                pets.push_back(std::make_shared<Bird>(name, age, weight, color, wingspan, canFly == 1));
                break;
            }
            case 4: {
                std::string waterType;
                int finCount;
                std::cout << "Water type (Freshwater/Saltwater): ";
                std::cin >> waterType;
                std::cout << "Number of fins: ";
                std::cin >> finCount;
                pets.push_back(std::make_shared<Fish>(name, age, weight, color, waterType, finCount));
                break;
            }
            case 5: {
                int hasWheel;
                std::string cageSize;
                std::cout << "Has exercise wheel? (1-yes/0-no): ";
                std::cin >> hasWheel;
                std::cout << "Cage size (Small/Medium/Large): ";
                std::cin >> cageSize;
                pets.push_back(std::make_shared<Hamster>(name, age, weight, color, hasWheel == 1, cageSize));
                break;
            }
            default:
                std::cout << "Invalid choice!\n";
        }

        std::cout << "Pet added successfully!\n";
    }

    void editPet() {
        if (pets.empty()) {
            std::cout << "No pets to edit!\n";
            return;
        }

        displayAllPets();
        std::cout << "Enter index to edit (0-" << pets.size() - 1 << "): ";
        int index;
        std::cin >> index;

        if (index >= 0 && index < static_cast<int>(pets.size())) {
            pets[index]->edit();
            std::cout << "Pet updated successfully!\n";
        } else {
            std::cout << "Invalid index!\n";
        }
    }

    void deletePet() {
        if (pets.empty()) {
            std::cout << "No pets to delete!\n";
            return;
        }

        displayAllPets();
        std::cout << "Enter index to delete (0-" << pets.size() - 1 << "): ";
        int index;
        std::cin >> index;

        if (index >= 0 && index < static_cast<int>(pets.size())) {
            pets.erase(pets.begin() + index);
            std::cout << "Pet deleted successfully!\n";
        } else {
            std::cout << "Invalid index!\n";
        }
    }

    void displayAllPets() const {
        if (pets.empty()) {
            std::cout << "\n No pets in the collection \n";
            return;
        }

        std::cout << "\n Pet Collection \n";
        for (size_t i = 0; i < pets.size(); ++i) {
            std::cout << "\n[" << i << "]\n";
            pets[i]->display();
        }
    }

    void saveToFile() {
        std::string filename;
        std::cout << "Enter filename to save (e.g., pets.json): ";
        std::cin >> filename;

        if (serializer.saveToFile(pets, filename)) {
            std::cout << "Successfully saved " << pets.size() << " pets to " << filename << "\n";
        } else {
            std::cout << "Failed to save to file!\n";
        }
    }

    void loadFromFile() {
        std::string filename;
        std::cout << "Enter filename to load (e.g., pets.json): ";
        std::cin >> filename;

        auto loadedPets = serializer.loadFromFile(filename);
        if (loadedPets) {
            pets = std::move(*loadedPets);
            std::cout << "Successfully loaded " << pets.size() << " pets from " << filename << "\n";
        } else {
            std::cout << "Failed to load from file!\n";
        }
    }

    bool isEmpty() const {
        return pets.empty();
    }
};

void showMenu() {

    std::cout << "        PET MANAGEMENT SYSTEM        \n";
    std::cout << "  1. Add new pet                     \n";
    std::cout << "  2. Edit pet                        \n";
    std::cout << "  3. Delete pet                      \n";
    std::cout << "  4. Display all pets                \n";
    std::cout << "  5. Save to JSON file               \n";
    std::cout << "  6. Load from JSON file             \n";
    std::cout << "  7. Exit                            \n";
    std::cout << "Choice: ";
}

int main() {
    PetManager manager;
    int choice;

    while (true) {
        showMenu();
        std::cin >> choice;

        switch (choice) {
            case 1:
                manager.addPet();
                break;
            case 2:
                manager.editPet();
                break;
            case 3:
                manager.deletePet();
                break;
            case 4:
                manager.displayAllPets();
                break;
            case 5:
                manager.saveToFile();
                break;
            case 6:
                manager.loadFromFile();
                break;
            case 7:
                std::cout << "\nGoodbye! Thanks for using Pet Management System! \n";
                return 0;
            default:
                std::cout << "Invalid choice! Please enter 1-7.\n";
        }
    }

    return 0;
}