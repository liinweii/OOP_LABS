#include "Animal.h"
#include <iostream>

Animal::Animal(const std::string& name, int age, double weight, const std::string& color)
    : name(name), age(age), weight(weight), color(color) {}

// Static registry for animal types
std::unordered_map<std::string, Animal::Creator>& Animal::getRegistry() {
    static std::unordered_map<std::string, Creator> registry;
    return registry;
}

void Animal::registerType(const std::string& type, Creator creator) {
    getRegistry()[type] = creator;
}

std::shared_ptr<Animal> Animal::createFromJson(const json& j) {
    std::string type = j.value("type", "");
    auto& registry = getRegistry();

    auto it = registry.find(type);
    if (it != registry.end()) {
        return it->second(j);
    }

    std::cerr << "Error: Unknown animal type: " << type << std::endl;
    return nullptr;
}