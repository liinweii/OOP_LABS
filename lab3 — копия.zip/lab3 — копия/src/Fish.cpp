#include "Fish.h"
#include "RegisterHelper.h"
#include <iostream>

// Automatic registration - no if-else needed!
static RegisterHelper<Fish> registryFish("Fish");

Fish::Fish(const std::string& name, int age, double weight, const std::string& color,
           const std::string& waterType, int finCount)
    : Animal(name, age, weight, color), waterType(waterType), finCount(finCount) {}

Fish::Fish(const json& j) {
    fromJson(j);
}

json Fish::toJson() const {
    json j;
    j["type"] = "Fish";
    j["name"] = name;
    j["age"] = age;
    j["weight"] = weight;
    j["color"] = color;
    j["waterType"] = waterType;
    j["finCount"] = finCount;
    return j;
}

void Fish::fromJson(const json& j) {
    name = j.value("name", "");
    age = j.value("age", 0);
    weight = j.value("weight", 0.0);
    color = j.value("color", "");
    waterType = j.value("waterType", "Freshwater");
    finCount = j.value("finCount", 0);
}

void Fish::display() const {
    std::cout << " FISH\n";
    std::cout << "  Name: " << name << "\n";
    std::cout << "  Age: " << age << " years\n";
    std::cout << "  Weight: " << weight << " kg\n";
    std::cout << "  Color: " << color << "\n";
    std::cout << "  Water Type: " << waterType << "\n";
    std::cout << "  Fin Count: " << finCount << "\n";
}

void Fish::edit() {
    std::cout << "\nEditing Fish\n";
    std::cout << "Name (" << name << "): ";
    std::string input;
    std::cin.ignore();
    std::getline(std::cin, input);
    if (!input.empty()) name = input;

    std::cout << "Age (" << age << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) age = std::stoi(input);

    std::cout << "Weight (" << weight << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) weight = std::stod(input);

    std::cout << "Color (" << color << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) color = input;

    std::cout << "Water Type (Freshwater/Saltwater) (" << waterType << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) waterType = input;

    std::cout << "Fin Count (" << finCount << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) finCount = std::stoi(input);
}