#include "JsonSerializer.h"
#include <fstream>
#include <iostream>
#include <json.hpp>

using json = nlohmann::json;

bool JsonSerializer::saveToFile(const std::vector<std::shared_ptr<Animal>>& animals, const std::string& filename) {
    try {
        json j;
        json animalsArray = json::array();
        
        for (const auto& animal : animals) {
            animalsArray.push_back(animal->toJson());
        }
        
        j["animals"] = animalsArray;
        j["count"] = animals.size();
        
        std::ofstream file(filename);
        if (!file.is_open()) {
            std::cerr << "Error: Cannot open file for writing: " << filename << std::endl;
            return false;
        }
        
        file << j.dump(4); // Pretty print with 4 spaces indentation
        file.close();
        return true;
        
    } catch (const std::exception& e) {
        std::cerr << "Error saving to JSON: " << e.what() << std::endl;
        return false;
    }
}

std::unique_ptr<std::vector<std::shared_ptr<Animal>>> JsonSerializer::loadFromFile(const std::string& filename) {
    try {
        std::ifstream file(filename);
        if (!file.is_open()) {
            std::cerr << "Error: Cannot open file for reading: " << filename << std::endl;
            return nullptr;
        }
        
        json j;
        file >> j;
        file.close();
        
        auto animals = std::make_unique<std::vector<std::shared_ptr<Animal>>>();
        
        if (j.contains("animals") && j["animals"].is_array()) {
            for (const auto& animalJson : j["animals"]) {
                auto animal = Animal::createFromJson(animalJson);
                if (animal) {
                    animals->push_back(animal);
                }
            }
        }
        
        return animals;
        
    } catch (const std::exception& e) {
        std::cerr << "Error loading from JSON: " << e.what() << std::endl;
        return nullptr;
    }
}