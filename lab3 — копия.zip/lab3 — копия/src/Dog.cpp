#include "Dog.h"
#include "RegisterHelper.h"
#include <iostream>

static RegisterHelper<Dog> registryDog("Dog");

Dog::Dog(const std::string& name, int age, double weight, const std::string& color,
         const std::string& breed, bool isTrained)
    : Animal(name, age, weight, color), breed(breed), isTrained(isTrained) {}

Dog::Dog(const json& j) {
    fromJson(j);
}

json Dog::toJson() const {
    json j;
    j["type"] = "Dog";
    j["name"] = name;
    j["age"] = age;
    j["weight"] = weight;
    j["color"] = color;
    j["breed"] = breed;
    j["isTrained"] = isTrained;
    return j;
}

void Dog::fromJson(const json& j) {
    name = j.value("name", "");
    age = j.value("age", 0);
    weight = j.value("weight", 0.0);
    color = j.value("color", "");
    breed = j.value("breed", "");
    isTrained = j.value("isTrained", false);
}

void Dog::display() const {
    std::cout << " DOG\n";
    std::cout << "  Name: " << name << "\n";
    std::cout << "  Age: " << age << " years\n";
    std::cout << "  Weight: " << weight << " kg\n";
    std::cout << "  Color: " << color << "\n";
    std::cout << "  Breed: " << breed << "\n";
    std::cout << "  Trained: " << (isTrained ? "Yes" : "No") << "\n";
}

void Dog::edit() {
    std::cout << "\nEditing Dog\n";
    std::cout << "Name (" << name << "): ";
    std::string input;
    std::cin.ignore();
    std::getline(std::cin, input);
    if (!input.empty()) name = input;
    
    std::cout << "Age (" << age << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) age = std::stoi(input);
    
    std::cout << "Weight (" << weight << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) weight = std::stod(input);
    
    std::cout << "Color (" << color << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) color = input;
    
    std::cout << "Breed (" << breed << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) breed = input;
    
    std::cout << "Is Trained? (1-yes/0-no) (" << isTrained << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) isTrained = (input == "1");
}