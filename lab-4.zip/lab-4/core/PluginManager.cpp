#include "PluginManager.h"
#include "PluginAPI.h"
#include "Animal.h"
#include <iostream>
#include <filesystem>
#include <fstream>
#include <chrono>

namespace fs = std::filesystem;

PluginManager::PluginManager() {
    // Set default plugins directory relative to executable
    #ifdef _WIN32
        pluginsDirectory = "./plugins/";
    #else
        pluginsDirectory = "./plugins/";
    #endif
}

PluginManager::~PluginManager() {
    unloadAllPlugins();
}

void PluginManager::setPluginsDirectory(const std::string& dir) {
    pluginsDirectory = dir;
    std::cout << "[PluginManager] Plugins directory set to: " << pluginsDirectory << std::endl;
}

uint32_t PluginManager::calculateChecksum(const std::string& filePath) {
    std::ifstream file(filePath, std::ios::binary);
    if (!file.is_open()) return 0;

    uint32_t checksum = 0;
    char buffer[4096];

    while (file.read(buffer, sizeof(buffer))) {
        for (size_t i = 0; i < file.gcount(); ++i) {
            checksum += static_cast<unsigned char>(buffer[i]);
        }
    }

    return checksum;
}

bool PluginManager::verifySignature(const std::string& pluginPath, const PluginSignature& signature) {
    uint64_t currentSize = fs::file_size(pluginPath);
    uint32_t currentChecksum = calculateChecksum(pluginPath);

    if (currentSize != signature.fileSize) {
        std::cerr << "Signature verification failed: File size mismatch" << std::endl;
        return false;
    }

    if (currentChecksum != signature.checksum) {
        std::cerr << "Signature verification failed: Checksum mismatch" << std::endl;
        return false;
    }

    auto now = std::chrono::system_clock::now();
    auto now_time = std::chrono::system_clock::to_time_t(now);
    uint64_t currentTimestamp = static_cast<uint64_t>(now_time);

    if (signature.timestamp < currentTimestamp) {
        if (currentTimestamp - signature.timestamp > 30 * 24 * 60 * 60) {
            std::cerr << "Signature verification failed: Plugin expired" << std::endl;
            return false;
        }
    }

    std::cout << "[Signature] Plugin signature verified successfully" << std::endl;
    return true;
}

bool PluginManager::loadPlugin(const std::string& pluginPath) {
    std::cout << "[PluginManager] Attempting to load plugin: " << pluginPath << std::endl;

    // Check if file exists
    if (!fs::exists(pluginPath)) {
        std::cerr << "[PluginManager] Plugin file not found: " << pluginPath << std::endl;
        return false;
    }

    std::cout << "[PluginManager] File exists, size: " << fs::file_size(pluginPath) << " bytes" << std::endl;

#ifdef _WIN32
    PluginHandle handle = LoadLibraryA(pluginPath.c_str());
    if (!handle) {
        std::cerr << "[PluginManager] Failed to load plugin. Error code: " << GetLastError() << std::endl;

        // Get detailed error message
        LPVOID lpMsgBuf;
        DWORD dw = GetLastError();
        FormatMessageA(
            FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
            NULL, dw, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
            (LPSTR)&lpMsgBuf, 0, NULL);
        std::cerr << "[PluginManager] Error details: " << (char*)lpMsgBuf << std::endl;
        LocalFree(lpMsgBuf);
        return false;
    }

    createPlugin = (CreatePluginFunction)GetProcAddress(handle, CREATE_PLUGIN_FUNC);
    destroyPlugin = (DestroyPluginFunction)GetProcAddress(handle, DESTROY_PLUGIN_FUNC);

    if (!createPlugin) {
        std::cerr << "[PluginManager] Failed to find createPlugin function. Error: " << GetLastError() << std::endl;
        FreeLibrary(handle);
        return false;
    }
    if (!destroyPlugin) {
        std::cerr << "[PluginManager] Failed to find destroyPlugin function" << std::endl;
        FreeLibrary(handle);
        return false;
    }
#else
    PluginHandle handle = dlopen(pluginPath.c_str(), RTLD_NOW);
    if (!handle) {
        std::cerr << "[PluginManager] Failed to load plugin: " << dlerror() << std::endl;
        return false;
    }

    // Clear any existing error
    dlerror();

    createPlugin = (CreatePluginFunction)dlsym(handle, CREATE_PLUGIN_FUNC);
    const char* dlsym_error = dlerror();
    if (dlsym_error) {
        std::cerr << "[PluginManager] Failed to find createPlugin function: " << dlsym_error << std::endl;
        dlclose(handle);
        return false;
    }

    destroyPlugin = (DestroyPluginFunction)dlsym(handle, DESTROY_PLUGIN_FUNC);
    dlsym_error = dlerror();
    if (dlsym_error) {
        std::cerr << "[PluginManager] Failed to find destroyPlugin function: " << dlsym_error << std::endl;
        dlclose(handle);
        return false;
    }
#endif

    std::cout << "[PluginManager] Plugin functions found successfully" << std::endl;

    IPlugin* plugin = createPlugin();
    if (!plugin) {
        std::cerr << "[PluginManager] Failed to create plugin instance" << std::endl;
#ifdef _WIN32
        FreeLibrary(handle);
#else
        dlclose(handle);
#endif
        return false;
    }

    PluginInfo info = plugin->getInfo();
    std::cout << "[PluginManager] Plugin info: " << info.name << " v" << info.version
              << " by " << info.author << std::endl;

    if (info.apiVersion != PLUGIN_API_VERSION) {
        std::cerr << "[PluginManager] Plugin API version mismatch: " << info.apiVersion
                  << " (expected " << PLUGIN_API_VERSION << ")" << std::endl;
        destroyPlugin(plugin);
#ifdef _WIN32
        FreeLibrary(handle);
#else
        dlclose(handle);
#endif
        return false;
    }

    if (!plugin->initialize()) {
        std::cerr << "[PluginManager] Plugin initialization failed" << std::endl;
        destroyPlugin(plugin);
#ifdef _WIN32
        FreeLibrary(handle);
#else
        dlclose(handle);
#endif
        return false;
    }

    auto creators = plugin->getAnimalCreators();
    std::cout << "[PluginManager] Registering " << creators.size() << " animal types" << std::endl;
    for (const auto& creator : creators) {
        Animal::registerType(creator.first, creator.second);
    }

    LoadedPlugin loaded;
    loaded.handle = handle;
    loaded.instance = plugin;
    loaded.path = pluginPath;
    loaded.info = info;
    loadedPlugins.push_back(loaded);

    std::cout << "[PluginManager] Plugin loaded successfully: " << info.name << std::endl;
    for (const auto& type : info.animalTypes) {
        std::cout << "  - Registered: " << type << std::endl;
    }

    return true;
}

int PluginManager::loadAllPlugins() {
    int count = 0;

    std::cout << "[PluginManager] Scanning plugins directory: " << pluginsDirectory << std::endl;

    // Check if directory exists
    if (!fs::exists(pluginsDirectory)) {
        std::cerr << "[PluginManager] Plugins directory does not exist: " << pluginsDirectory << std::endl;

        // Try current directory as fallback
        fs::path currentPath = fs::current_path();
        std::cout << "[PluginManager] Current working directory: " << currentPath << std::endl;

        // Try to find plugins in common locations
        std::vector<std::string> possiblePaths = {
            pluginsDirectory,
            "./plugins/",
            "../plugins/",
            currentPath.string() + "/plugins/",
            currentPath.string() + "/../bin/plugins/",
            "plugins/"
        };

        for (const auto& path : possiblePaths) {
            if (fs::exists(path)) {
                std::cout << "[PluginManager] Found plugins directory: " << path << std::endl;
                pluginsDirectory = path;
                break;
            }
        }

        if (!fs::exists(pluginsDirectory)) {
            std::cerr << "[PluginManager] Creating plugins directory: " << pluginsDirectory << std::endl;
            fs::create_directories(pluginsDirectory);
            return 0;
        }
    }

    // Iterate through plugin files
    std::cout << "[PluginManager] Looking for plugins in: " << pluginsDirectory << std::endl;

    for (const auto& entry : fs::directory_iterator(pluginsDirectory)) {
        std::string extension = entry.path().extension().string();
        std::string filename = entry.path().filename().string();

        std::cout << "[PluginManager] Found file: " << filename << " (ext: " << extension << ")" << std::endl;

#ifdef _WIN32
        if (extension == ".dll") {
            std::cout << "[PluginManager] Found DLL: " << entry.path().string() << std::endl;
            if (loadPlugin(entry.path().string())) {
                count++;
            }
        }
#else
        if (extension == ".so" || extension == ".dylib") {
            std::cout << "[PluginManager] Found shared library: " << entry.path().string() << std::endl;
            if (loadPlugin(entry.path().string())) {
                count++;
            }
        }
#endif
    }

    std::cout << "[PluginManager] Loaded " << count << " plugins" << std::endl;
    return count;
}

bool PluginManager::loadPluginByName(const std::string& pluginName) {
    std::string pluginPath;

#ifdef _WIN32
    pluginPath = pluginsDirectory + pluginName + ".dll";
#else
    pluginPath = pluginsDirectory + "lib" + pluginName + ".so";
#endif

    return loadPlugin(pluginPath);
}

void PluginManager::unloadAllPlugins() {
    for (auto& plugin : loadedPlugins) {
        for (const auto& type : plugin.info.animalTypes) {
            Animal::unregisterType(type);
        }

        plugin.instance->cleanup();
        destroyPlugin(plugin.instance);
        
#ifdef _WIN32
        FreeLibrary(plugin.handle);
#else
        dlclose(plugin.handle);
#endif
        
        std::cout << "[PluginManager] Unloaded plugin: " << plugin.info.name << std::endl;
    }
    
    loadedPlugins.clear();
}

std::vector<std::string> PluginManager::getPluginAnimalTypes() const {
    std::vector<std::string> types;
    for (const auto& plugin : loadedPlugins) {
        for (const auto& type : plugin.info.animalTypes) {
            types.push_back(type);
        }
    }
    return types;
}

std::vector<std::pair<std::string, std::string>> PluginManager::getPluginMenuItems() const {
    std::vector<std::pair<std::string, std::string>> items;
    for (const auto& plugin : loadedPlugins) {
        auto pluginItems = plugin.instance->getMenuItems();
        items.insert(items.end(), pluginItems.begin(), pluginItems.end());
    }
    return items;
}

std::vector<std::string> PluginManager::getLoadedPluginNames() const {
    std::vector<std::string> names;
    for (const auto& plugin : loadedPlugins) {
        names.push_back(plugin.info.name);
    }
    return names;
}

std::vector<FieldInfo> PluginManager::getFieldsForType(const std::string& type) const {
    for (const auto& plugin : loadedPlugins) {
        auto fields = plugin.instance->getFieldsForType(type);
        if (!fields.empty()) {
            return fields;
        }
    }
    return {};
}

std::shared_ptr<Animal> PluginManager::createPluginAnimal(const std::string& type,
    const std::vector<std::pair<std::string, std::string>>& fieldValues) const {

    for (const auto& plugin : loadedPlugins) {
        auto animal = plugin.instance->createFromFields(type, fieldValues);
        if (animal) {
            return animal;
        }
    }
    return nullptr;
}

bool PluginManager::isPluginType(const std::string& type) const {
    for (const auto& plugin : loadedPlugins) {
        for (const auto& animalType : plugin.info.animalTypes) {
            if (animalType == type) {
                return true;
            }
        }
    }
    return false;
}