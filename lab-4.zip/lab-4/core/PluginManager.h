#ifndef PLUGIN_MANAGER_H
#define PLUGIN_MANAGER_H

#include "PluginAPI.h"
#include "Animal.h"
#include <string>
#include <vector>
#include <memory>
#include <unordered_map>

#ifdef _WIN32
    #include <windows.h>
    typedef HMODULE PluginHandle;
#else
    #include <dlfcn.h>
    typedef void* PluginHandle;
#endif

/**
 * Plugin Manager class
 * Handles dynamic loading/unloading of plugins
 */
class PluginManager {
private:
    struct LoadedPlugin {
        PluginHandle handle;
        IPlugin* instance;
        std::string path;
        PluginInfo info;
    };
    
    std::vector<LoadedPlugin> loadedPlugins;
    std::string pluginsDirectory;
    
    // Function pointers for plugin management
    CreatePluginFunction createPlugin = nullptr;
    DestroyPluginFunction destroyPlugin = nullptr;
    
#ifdef _WIN32
    // Windows-specific handle management
#else
    // Unix-specific handle management
#endif
    
    /**
     * Load a single plugin from file
     * @param pluginPath - Path to plugin shared library
     * @return true if loaded successfully
     */
    bool loadPlugin(const std::string& pluginPath);
    
    /**
     * Verify plugin signature (bonus task)
     * @param pluginPath - Path to plugin file
     * @param signature - Plugin signature
     * @return true if signature is valid
     */
    bool verifySignature(const std::string& pluginPath, const PluginSignature& signature);
    
    /**
     * Calculate file checksum for integrity verification
     * @param filePath - Path to file
     * @return Checksum value
     */
    uint32_t calculateChecksum(const std::string& filePath);
    
public:
    PluginManager();
    ~PluginManager();
    
    /**
     * Set plugins directory
     * @param dir - Directory path
     */
    void setPluginsDirectory(const std::string& dir);
    
    /**
     * Load all plugins from the plugins directory
     * @return Number of plugins loaded
     */
    int loadAllPlugins();
    
    /**
     * Load a specific plugin by name
     * @param pluginName - Name of the plugin file (without extension)
     * @return true if loaded successfully
     */
    bool loadPluginByName(const std::string& pluginName);
    
    /**
     * Unload all plugins
     */
    void unloadAllPlugins();
    
    /**
     * Get all registered animal types from plugins
     * @return Vector of type names
     */
    std::vector<std::string> getPluginAnimalTypes() const;
    
    /**
     * Get all menu items from plugins
     * @return Vector of (menuText, typeName) pairs
     */
    std::vector<std::pair<std::string, std::string>> getPluginMenuItems() const;
    
    /**
     * Get list of loaded plugin names
     * @return Vector of plugin names
     */
    std::vector<std::string> getLoadedPluginNames() const;

    std::vector<FieldInfo> getFieldsForType(const std::string& type) const;
    std::shared_ptr<Animal> createPluginAnimal(const std::string& type,
        const std::vector<std::pair<std::string, std::string>>& fieldValues) const;
    bool isPluginType(const std::string& type) const;
};

#endif