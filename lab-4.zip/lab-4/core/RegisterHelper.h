#ifndef REGISTER_HELPER_H
#define REGISTER_HELPER_H

#include "Animal.h"

/**
 * Helper template for automatic registration of animal types
 */
template<typename T>
class RegisterHelper {
public:
    RegisterHelper(const std::string& type) {
        Animal::registerType(type, [](const json& j) -> std::shared_ptr<Animal> {
            return std::make_shared<T>(j);
        });
    }
    
    ~RegisterHelper() {
        // Optional: unregister on destruction
    }
};

#endif