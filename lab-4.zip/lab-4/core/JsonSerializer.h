#ifndef JSON_SERIALIZER_H
#define JSON_SERIALIZER_H

#include <vector>
#include <memory>
#include <string>
#include "Animal.h"

class JsonSerializer {
public:
    bool saveToFile(const std::vector<std::shared_ptr<Animal>>& animals, const std::string& filename);
    std::unique_ptr<std::vector<std::shared_ptr<Animal>>> loadFromFile(const std::string& filename);
};

#endif