// core/src/Animal.cpp
#include "Animal.h"
#include <iostream>

std::unordered_map<std::string, Animal::Creator>& Animal::getRegistry() {
    static std::unordered_map<std::string, Creator> registry;
    return registry;
}

void Animal::registerType(const std::string& type, Creator creator) {
    getRegistry()[type] = creator;
    std::cout << "[Registry] Registered animal type: " << type << std::endl;
}

void Animal::unregisterType(const std::string& type) {
    getRegistry().erase(type);
    std::cout << "[Registry] Unregistered animal type: " << type << std::endl;
}

std::shared_ptr<Animal> Animal::createFromJson(const json& j) {
    std::string type = j.value("type", "");
    auto& registry = getRegistry();
    
    auto it = registry.find(type);
    if (it != registry.end()) {
        return it->second(j);
    }
    
    std::cerr << "Error: Unknown animal type: " << type << std::endl;
    return nullptr;
}

std::vector<std::string> Animal::getRegisteredTypes() {
    std::vector<std::string> types;
    for (const auto& pair : getRegistry()) {
        types.push_back(pair.first);
    }
    return types;
}