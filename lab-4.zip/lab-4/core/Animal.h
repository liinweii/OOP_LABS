// core/include/Animal.h
#ifndef ANIMAL_H
#define ANIMAL_H

#include <string>
#include <memory>
#include <functional>
#include <unordered_map>
#include <json.hpp>

using json = nlohmann::json;

class Animal {
protected:
    std::string name;
    int age;
    double weight;
    std::string color;

public:
    Animal(const std::string& n = "", int a = 0, double w = 0.0,
               const std::string& c = "")
            : name(n), age(a), weight(w), color(c) {}
    virtual ~Animal() = default;

    virtual std::string getName() const { return name; }
    virtual int getAge() const { return age; }
    virtual double getWeight() const { return weight; }
    virtual std::string getColor() const { return color; }

    virtual void setName(const std::string& n) { name = n; }
    virtual void setAge(int a) { age = a; }
    virtual void setWeight(double w) { weight = w; }
    virtual void setColor(const std::string& c) { color = c; }

    virtual json toJson() const = 0;
    virtual void fromJson(const json& j) = 0;
    virtual void display() const = 0;
    virtual std::string getType() const = 0;
    virtual void edit() = 0;

    using Creator = std::function<std::shared_ptr<Animal>(const json&)>;

    static void registerType(const std::string& type, Creator creator);
    static void unregisterType(const std::string& type);
    static std::shared_ptr<Animal> createFromJson(const json& j);
    static std::vector<std::string> getRegisteredTypes();
    
private:
    static std::unordered_map<std::string, Creator>& getRegistry();
};

#endif