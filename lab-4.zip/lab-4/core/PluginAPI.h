// core/include/PluginAPI.h
#ifndef PLUGIN_API_H
#define PLUGIN_API_H

#include <string>
#include <memory>
#include <functional>
#include <vector>
#include <json.hpp>
#include "Animal.h"  // Используем существующий Animal.h

using json = nlohmann::json;

//=============================================================================
// Platform-specific export macros for plugins
//=============================================================================

// Plugin API version
#define PLUGIN_API_VERSION 1

// Define PLUGIN_EXPORT macro for different platforms
#ifdef _WIN32
    // Windows: __declspec(dllexport) for exporting from DLL
    #ifdef PLUGIN_EXPORTS
        #define PLUGIN_EXPORT __declspec(dllexport)
    #else
        #define PLUGIN_EXPORT __declspec(dllimport)
    #endif
#else
    // Linux/Mac: default visibility
    #if __GNUC__ >= 4
        #define PLUGIN_EXPORT __attribute__((visibility("default")))
    #else
        #define PLUGIN_EXPORT
    #endif
#endif

// Alias for compatibility
#define PLUGIN_API PLUGIN_EXPORT

//=============================================================================
// Field description for interactive creation
//=============================================================================
struct FieldInfo {
    std::string name;        // Field name (e.g., "length", "canTalk")
    std::string type;        // Field type: "string", "int", "double", "bool"
    std::string label;       // Display label (e.g., "Length (meters): ")
    std::string defaultValue;// Default value as string
    bool required;           // Is field required?

    FieldInfo() : required(true) {}

    FieldInfo(const std::string& n, const std::string& t,
              const std::string& l, const std::string& d = "", bool r = true)
        : name(n), type(t), label(l), defaultValue(d), required(r) {}
};

//=============================================================================
// Plugin Information Structure
//=============================================================================
struct PluginInfo {
    std::string name;           // Plugin name
    std::string version;        // Plugin version
    std::string author;         // Plugin author
    int apiVersion;             // API version this plugin targets
    std::vector<std::string> animalTypes;  // Animal types provided by this plugin
};

/**
 * Plugin signature structure (for bonus task)
 */
struct PluginSignature {
    uint64_t timestamp;         // Activation timestamp
    uint64_t fileSize;          // Original file size
    uint32_t checksum;          // Simple checksum for integrity
    std::string publicKey;      // Public key for verification
};

//=============================================================================
// Abstract Plugin Interface
// All plugins must implement this interface
//=============================================================================
class IPlugin {
public:
    virtual ~IPlugin() = default;

    /**
     * Get plugin information
     * @return PluginInfo structure with plugin metadata
     */
    virtual PluginInfo getInfo() const = 0;

    /**
     * Initialize the plugin
     * Called when plugin is loaded
     * @return true if initialization successful
     */
    virtual bool initialize() = 0;

    /**
     * Cleanup the plugin
     * Called when plugin is unloaded
     */
    virtual void cleanup() = 0;

    /**
     * Get all animal creators from this plugin
     * Each creator is a function that creates an animal from JSON
     */
    virtual std::vector<std::pair<std::string, std::function<std::shared_ptr<Animal>(const json&)>>>
        getAnimalCreators() const = 0;

    /**
     * Get menu items to add to UI
     * Returns pairs of (menuText, typeName)
     */
    virtual std::vector<std::pair<std::string, std::string>> getMenuItems() const = 0;

    /**
     * Get fields for interactive creation of a specific animal type
     * Returns list of fields with their types and labels
     */
    virtual std::vector<FieldInfo> getFieldsForType(const std::string& type) const = 0;

    /**
     * Create animal from field values (collected from user input)
     * @param type - Animal type name
     * @param fieldValues - Vector of (fieldName, fieldValue) pairs
     * @return shared_ptr to created Animal or nullptr
     */
    virtual std::shared_ptr<Animal> createFromFields(const std::string& type,
        const std::vector<std::pair<std::string, std::string>>& fieldValues) const = 0;
};

/**
 * Plugin creation function type
 */
typedef IPlugin* (*CreatePluginFunction)();

/**
 * Plugin destruction function type
 */
typedef void (*DestroyPluginFunction)(IPlugin*);

// Function name exports that plugins must implement
#define CREATE_PLUGIN_FUNC "createPlugin"
#define DESTROY_PLUGIN_FUNC "destroyPlugin"

#endif // PLUGIN_API_H