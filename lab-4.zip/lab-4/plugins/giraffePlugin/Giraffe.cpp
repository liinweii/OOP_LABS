#include "../../core/PluginAPI.h"
#include "GiraffeAdapter.h"
#include <iostream>

// =============================================================================
// GiraffePlugin — регистрирует тип "Giraffe" через GiraffeAdapter
// =============================================================================
class GiraffePlugin : public IPlugin {
public:
    // -------------------------------------------------------------------------
    PluginInfo getInfo() const override {
        PluginInfo info;
        info.name        = "Giraffe Plugin";
        info.version     = "1.0.0";
        info.author      = "lin";
        info.apiVersion  = PLUGIN_API_VERSION;
        info.animalTypes = {"Giraffe"};
        return info;
    }

    // -------------------------------------------------------------------------
    bool initialize() override {
        std::cout << "[GiraffePlugin] Ready (using Adapter pattern)" << std::endl;
        return true;
    }

    void cleanup() override {}

    // -------------------------------------------------------------------------
    // Фабрика: JSON → GiraffeAdapter (через Animal-интерфейс)
    // -------------------------------------------------------------------------
    std::vector<std::pair<std::string,
        std::function<std::shared_ptr<Animal>(const json&)>>>
    getAnimalCreators() const override {
        return {
            {"Giraffe", [](const json& j) {
                return std::make_shared<GiraffeAdapter>(j);
            }}
        };
    }

    // -------------------------------------------------------------------------
    std::vector<std::pair<std::string, std::string>>
    getMenuItems() const override {
        return {{" Giraffe", "Giraffe"}};
    }

    // -------------------------------------------------------------------------
    // Описание полей для интерактивного создания в PetManager::addPet()
    // -------------------------------------------------------------------------
    std::vector<FieldInfo>
    getFieldsForType(const std::string& type) const override {
        if (type != "Giraffe") return {};
        return {
            {"name",        "string", "Name: ",                    "",   true},
            {"age",         "int",    "Age (years): ",             "0",  true},
            {"weight",      "double", "Weight (kg): ",             "0",  true},
            {"color",       "string", "Spot pattern "
                                      "(e.g. Reticulated/Masai): ","",   true},
            {"neckLengthCm","double", "Neck length (cm): ",        "0",  true},
            {"isWild",      "bool",   "Is wild? (1/0): ",          "1",  false}
        };
    }

    // -------------------------------------------------------------------------
    // Создание объекта из пар (fieldName, fieldValue)
    // -------------------------------------------------------------------------
    std::shared_ptr<Animal>
    createFromFields(const std::string& type,
        const std::vector<std::pair<std::string, std::string>>& values)
    const override {
        if (type != "Giraffe") return nullptr;

        std::string name, color;
        int    age          = 0;
        double weight       = 0.0;
        double neckLengthCm = 0.0;
        bool   isWild       = true;

        for (const auto& f : values) {
            if      (f.first == "name")         name         = f.second;
            else if (f.first == "age")          age          = std::stoi(f.second);
            else if (f.first == "weight")       weight       = std::stod(f.second);
            else if (f.first == "color")        color        = f.second;
            else if (f.first == "neckLengthCm") neckLengthCm = std::stod(f.second);
            else if (f.first == "isWild")       isWild       = (f.second == "1");
        }

        // GiraffeAdapter внутри создаёт ThirdPartyGiraffe с конвертацией единиц
        return std::make_shared<GiraffeAdapter>(
            name, age, weight, color, neckLengthCm, isWild
        );
    }
};

// =============================================================================
// C-экспорт
// =============================================================================
extern "C" {
    PLUGIN_EXPORT IPlugin* createPlugin()            { return new GiraffePlugin(); }
    PLUGIN_EXPORT void     destroyPlugin(IPlugin* p) { delete p; }
}