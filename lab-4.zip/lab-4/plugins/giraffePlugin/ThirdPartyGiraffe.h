//
// Created by polin on 21.05.2026.
//

#ifndef ANIMALPLUGINSYSTEM_THIRDPARTYGIRAFFE_H
#define ANIMALPLUGINSYSTEM_THIRDPARTYGIRAFFE_H

#include <string>
#include <iostream>

// =============================================================================
// ThirdPartyGiraffe — «чужой» класс с совершенно другим интерфейсом.
// Представим, что это пришло из сторонней библиотеки:
//   - не наследуется от Animal
//   - хранит данные в своих полях с другими именами
//   - использует сантиметры вместо килограммов для веса
//   - методы называются иначе (printInfo вместо display, serialize вместо toJson)
//   - нет fromJson — только конструктор и ручные сеттеры
// =============================================================================
class ThirdPartyGiraffe {
private:
    std::string giraffeId;      // внутренний ID (не name)
    int         ageInMonths;    // возраст в месяцах, а не годах
    double      weightInGrams;  // вес в граммах, а не кг
    std::string spotPattern;    // "Reticulated" / "Masai" / "Rothschild" etc.
    double      neckLengthCm;   // длина шеи в сантиметрах
    bool        isWild;         // дикое или домашнее

public:
    ThirdPartyGiraffe()
        : giraffeId("unknown"), ageInMonths(0),
          weightInGrams(0.0), spotPattern(""), neckLengthCm(0.0), isWild(true)
    {}

    ThirdPartyGiraffe(const std::string& id, int ageMonths, double weightGrams,
                      const std::string& pattern, double neckCm, bool wild)
        : giraffeId(id), ageInMonths(ageMonths), weightInGrams(weightGrams),
          spotPattern(pattern), neckLengthCm(neckCm), isWild(wild)
    {}

    // --- Геттеры (названия отличаются от Animal) ---
    const std::string& getId()          const { return giraffeId; }
    int                getAgeMonths()   const { return ageInMonths; }
    double             getWeightGrams() const { return weightInGrams; }
    const std::string& getPattern()     const { return spotPattern; }
    double             getNeckCm()      const { return neckLengthCm; }
    bool               getIsWild()      const { return isWild; }

    // --- Сеттеры ---
    void setId(const std::string& id)    { giraffeId   = id; }
    void setAgeMonths(int m)             { ageInMonths = m; }
    void setWeightGrams(double g)        { weightInGrams = g; }
    void setPattern(const std::string& p){ spotPattern  = p; }
    void setNeckCm(double cm)            { neckLengthCm = cm; }
    void setIsWild(bool w)               { isWild = w; }

    // --- «Чужой» метод вывода (не display()) ---
    void printInfo() const {
        std::cout << "[ThirdPartyGiraffe]\n";
        std::cout << "  ID      : " << giraffeId      << "\n";
        std::cout << "  Age     : " << ageInMonths     << " months\n";
        std::cout << "  Weight  : " << weightInGrams   << " g\n";
        std::cout << "  Pattern : " << spotPattern     << "\n";
        std::cout << "  Neck    : " << neckLengthCm    << " cm\n";
        std::cout << "  Wild    : " << (isWild ? "Yes" : "No") << "\n";
    }

    // --- «Чужой» метод сериализации — возвращает plain-text, а не JSON ---
    std::string serialize() const {
        return giraffeId + ";" +
               std::to_string(ageInMonths)   + ";" +
               std::to_string(weightInGrams) + ";" +
               spotPattern                   + ";" +
               std::to_string(neckLengthCm)  + ";" +
               (isWild ? "1" : "0");
    }

    // --- «Чужой» метод десериализации ---
    static ThirdPartyGiraffe deserialize(const std::string& data) {
        // Простой парсер строки вида "id;months;grams;pattern;neckCm;wild"
        ThirdPartyGiraffe g;
        std::istringstream ss(data);   // нужен <sstream> в .cpp
        std::string token;
        int field = 0;
        while (std::getline(ss, token, ';')) {
            switch (field++) {
                case 0: g.giraffeId     = token; break;
                case 1: g.ageInMonths   = std::stoi(token); break;
                case 2: g.weightInGrams = std::stod(token); break;
                case 3: g.spotPattern   = token; break;
                case 4: g.neckLengthCm  = std::stod(token); break;
                case 5: g.isWild        = (token == "1"); break;
            }
        }
        return g;
    }
};


#endif //ANIMALPLUGINSYSTEM_THIRDPARTYGIRAFFE_H