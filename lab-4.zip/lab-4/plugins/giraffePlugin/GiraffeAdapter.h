//
// Created by polin on 21.05.2026.
//

#ifndef ANIMALPLUGINSYSTEM_GIRAFFEADAPTER_H
#define ANIMALPLUGINSYSTEM_GIRAFFEADAPTER_H

#include "PluginAPI.h"           // Animal, json, ...
#include "ThirdPartyGiraffe.h"   // «чужой» класс

// =============================================================================
// GiraffeAdapter — паттерн «Адаптер» (Object Adapter)
//
// Задача: система ожидает Animal (toJson/fromJson/display/edit/getType),
//         а ThirdPartyGiraffe предоставляет другой интерфейс.
//         Адаптер оборачивает ThirdPartyGiraffe и транслирует вызовы.
//
// Преобразования единиц измерения:
//   - возраст  : месяцы  <-> годы   (/ 12)
//   - вес      : граммы  <-> кг     (/ 1000)
//   - шея      : см хранится как есть (дополнительное поле)
//   - цвет     : spotPattern  <-> color
//   - name     : giraffeId    <-> name
// =============================================================================
class GiraffeAdapter : public Animal {
private:
    ThirdPartyGiraffe adaptee;   // «адаптируемый» объект
    double neckLengthCm;         // дополнительное поле жирафа

    // ---------- Вспомогательные конверторы ----------
    static int    yearsToMonths(int years)    { return years * 12; }
    static int    monthsToYears(int months)   { return months / 12; }
    static double kgToGrams(double kg)        { return kg * 1000.0; }
    static double gramsToKg(double grams)     { return grams / 1000.0; }

    // Синхронизируем поля Animal (name/age/weight/color) ← ThirdPartyGiraffe
    void syncFromAdaptee() {
        name   = adaptee.getId();
        age    = monthsToYears(adaptee.getAgeMonths());
        weight = gramsToKg(adaptee.getWeightGrams());
        color  = adaptee.getPattern();
        neckLengthCm = adaptee.getNeckCm();
    }

    // Синхронизируем ThirdPartyGiraffe ← поля Animal
    void syncToAdaptee() {
        adaptee.setId(name);
        adaptee.setAgeMonths(yearsToMonths(age));
        adaptee.setWeightGrams(kgToGrams(weight));
        adaptee.setPattern(color);
        adaptee.setNeckCm(neckLengthCm);
    }

public:
    // ---------- Конструкторы ----------

    GiraffeAdapter()
        : Animal(), neckLengthCm(0.0) {}

    // Создание из полей системы (name, age-years, weight-kg, color=pattern, neck-cm, isWild)
    GiraffeAdapter(const std::string& name, int ageYears, double weightKg,
                   const std::string& spotPattern, double neckCm, bool isWild)
        : Animal(name, ageYears, weightKg, spotPattern), neckLengthCm(neckCm)
    {
        adaptee = ThirdPartyGiraffe(
            name,
            yearsToMonths(ageYears),
            kgToGrams(weightKg),
            spotPattern,
            neckCm,
            isWild
        );
    }

    // Создание напрямую из ThirdPartyGiraffe
    explicit GiraffeAdapter(const ThirdPartyGiraffe& g)
        : Animal(), adaptee(g), neckLengthCm(g.getNeckCm())
    {
        syncFromAdaptee();
    }

    // Создание из JSON (используется при загрузке из файла)
    explicit GiraffeAdapter(const json& j)
        : Animal(), neckLengthCm(0.0)
    {
        fromJson(j);
    }

    // ---------- Animal interface ----------

    std::string getType() const override { return "Giraffe"; }

    // Сериализация в JSON — формат системы
    json toJson() const override {
        json j;
        j["type"]        = "Giraffe";
        j["name"]        = name;
        j["age"]         = age;
        j["weight"]      = weight;
        j["color"]       = color;        // = spotPattern
        j["neckLengthCm"]= neckLengthCm;
        j["isWild"]      = adaptee.getIsWild();
        return j;
    }

    // Десериализация из JSON
    void fromJson(const json& j) override {
        name         = j.value("name",  "");
        age          = j.value("age",   0);
        weight       = j.value("weight",0.0);
        color        = j.value("color", "");
        neckLengthCm = j.value("neckLengthCm", 0.0);
        bool isWild  = j.value("isWild", true);

        // Восстанавливаем adaptee с конвертацией единиц
        adaptee = ThirdPartyGiraffe(
            name,
            yearsToMonths(age),
            kgToGrams(weight),
            color,
            neckLengthCm,
            isWild
        );
    }

    // Вывод: можно показать как «наш» формат, так и вызвать оригинальный printInfo
    void display() const override {
        std::cout << " GIRAFFE (Plugin + Adapter)\n";
        std::cout << "  Name (ID)   : " << name             << "\n";
        std::cout << "  Age         : " << age              << " years\n";
        std::cout << "  Weight      : " << weight           << " kg\n";
        std::cout << "  Spot pattern: " << color            << "\n";
        std::cout << "  Neck length : " << neckLengthCm     << " cm\n";
        std::cout << "  Wild        : " << (adaptee.getIsWild() ? "Yes" : "No") << "\n";

        // Для наглядности адаптера — вызываем «родной» метод ThirdPartyGiraffe
        std::cout << "  -- Raw ThirdPartyGiraffe data --\n";
        std::cout << "     ageInMonths  : " << adaptee.getAgeMonths()   << "\n";
        std::cout << "     weightGrams  : " << adaptee.getWeightGrams() << "\n";
    }

    // Интерактивное редактирование
    void edit() override {
        std::string input;
        std::cout << "Name (" << name << "): ";
        std::cin.ignore();
        std::getline(std::cin, input);
        if (!input.empty()) name = input;

        std::cout << "Age in years (" << age << "): ";
        std::getline(std::cin, input);
        if (!input.empty()) age = std::stoi(input);

        std::cout << "Weight in kg (" << weight << "): ";
        std::getline(std::cin, input);
        if (!input.empty()) weight = std::stod(input);

        std::cout << "Spot pattern (" << color << "): ";
        std::getline(std::cin, input);
        if (!input.empty()) color = input;

        std::cout << "Neck length cm (" << neckLengthCm << "): ";
        std::getline(std::cin, input);
        if (!input.empty()) neckLengthCm = std::stod(input);

        std::cout << "Is wild? (1/0) (" << adaptee.getIsWild() << "): ";
        std::getline(std::cin, input);
        bool isWild = input.empty() ? adaptee.getIsWild() : (input == "1");

        // Применяем изменения к ThirdPartyGiraffe через адаптер
        adaptee = ThirdPartyGiraffe(
            name,
            yearsToMonths(age),
            kgToGrams(weight),
            color,
            neckLengthCm,
            isWild
        );
    }

    // Доступ к «оригинальному» объекту (если нужен где-то напрямую)
    const ThirdPartyGiraffe& getAdaptee() const { return adaptee; }
};

#endif //ANIMALPLUGINSYSTEM_GIRAFFEADAPTER_H