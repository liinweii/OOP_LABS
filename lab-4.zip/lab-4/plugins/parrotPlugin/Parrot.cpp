#include "PluginAPI.h"   // содержит Animal.h, IPlugin, FieldInfo и пр.
#include <string>
#include <memory>
#include <functional>
#include <vector>

// =============================================================================
// Parrot — конкретный тип животного
// =============================================================================
class Parrot : public Animal {
private:
    bool canTalk;
    int  vocabularySize;

public:
    // Конструкторы
    Parrot(const std::string& name = "", int age = 0, double weight = 0.0,
           const std::string& color = "", bool canTalk = false, int vocabularySize = 0);

    explicit Parrot(const json& j);

    // Геттеры / сеттеры
    bool getCanTalk()       const { return canTalk; }
    int  getVocabularySize() const { return vocabularySize; }
    void setCanTalk(bool talk)    { canTalk = talk; }
    void setVocabularySize(int s) { vocabularySize = s; }

    // Переопределения Animal
    json        toJson()   const override;
    void        fromJson(const json& j) override;
    void        display()  const override;
    std::string getType()  const override { return "Parrot"; }
    void        edit()     override;
};

// =============================================================================
// ParrotPlugin — плагин, регистрирующий Parrot в системе
// =============================================================================
class ParrotPlugin : public IPlugin {
public:
    PluginInfo getInfo()    const override;
    bool       initialize()       override;
    void       cleanup()          override;

    std::vector<std::pair<std::string,
        std::function<std::shared_ptr<Animal>(const json&)>>>
        getAnimalCreators() const override;

    std::vector<std::pair<std::string, std::string>>
        getMenuItems() const override;

    // Методы для field-based интерактивного создания (PluginAPI.h)
    std::vector<FieldInfo>
        getFieldsForType(const std::string& type) const override;

    std::shared_ptr<Animal>
        createFromFields(const std::string& type,
            const std::vector<std::pair<std::string, std::string>>& values)
        const override;
};

// =============================================================================
// C-экспорт для динамической загрузки
// =============================================================================
extern "C" {
    PLUGIN_EXPORT IPlugin* createPlugin();
    PLUGIN_EXPORT void     destroyPlugin(IPlugin* plugin);
}
