#include <D:\oop\lab4\core\Animal.h>
#include <iostream>

#include "PluginAPI.h"

/**
 * Snake class - plugin animal
 */
class Snake : public Animal {
private:
    double length;       // Length in meters
    bool isVenomous;     // Whether the snake is venomous

public:
    Snake(const std::string& name = "", int age = 0, double weight = 0.0,
          const std::string& color = "", double length = 0.0, bool isVenomous = false);
    Snake(const json& j);
    
    double getLength() const { return length; }
    bool getIsVenomous() const { return isVenomous; }
    
    void setLength(double l) { length = l; }
    void setIsVenomous(bool v) { isVenomous = v; }
    
    json toJson() const override;
    void fromJson(const json& j) override;
    void display() const override;
    std::string getType() const override { return "Snake"; }
    void edit() override;
};

/**
 * Snake plugin implementation
 */
class SnakePlugin : public IPlugin {
public:
    PluginInfo getInfo() const override;
    bool initialize() override;
    void cleanup() override;
    std::vector<std::pair<std::string, std::function<std::shared_ptr<Animal>(const json&)>>> 
        getAnimalCreators() const override;
    std::vector<std::pair<std::string, std::string>> getMenuItems() const override;
};

// Export functions
extern "C" {
    PLUGIN_EXPORT IPlugin* createPlugin();
    PLUGIN_EXPORT void destroyPlugin(IPlugin* plugin);
}