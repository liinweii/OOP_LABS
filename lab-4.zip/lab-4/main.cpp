#include <iostream>
#include <vector>
#include <memory>
#include <string>
#include <limits>
#include <filesystem>
#include "core/Animal.h"
#include "core/JsonSerializer.h"
#include "core/PluginManager.h"
#include "core/RegisterHelper.h"

// Include built-in animals
#include "builtinAnimals/Dog.h"
#include "builtinAnimals/Cat.h"
#include "builtinAnimals/Bird.h"
#include "builtinAnimals/Fish.h"
#include "builtinAnimals/Hamster.h"

// Register built-in animals
static RegisterHelper<Dog> registerDog("Dog");
static RegisterHelper<Cat> registerCat("Cat");
static RegisterHelper<Bird> registerBird("Bird");
static RegisterHelper<Fish> registerFish("Fish");
static RegisterHelper<Hamster> registerHamster("Hamster");

class PetManager {
private:
    std::vector<std::shared_ptr<Animal>> pets;
    JsonSerializer serializer;
    PluginManager pluginManager;
    std::vector<std::pair<std::string, std::string>> pluginMenuItems;

    void clearInputBuffer() {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    void printRegisteredTypes() {
        auto types = Animal::getRegisteredTypes();
        std::cout << "\nAvailable animal types (" << types.size() << " total):\n";
        for (size_t i = 0; i < types.size(); ++i) {
            std::cout << "  " << (i + 1) << ". " << types[i] << std::endl;
        }
    }

public:
    PetManager() {
        std::cout << "[System] Current working directory: " << std::filesystem::current_path() << std::endl;

        // Try multiple possible plugin paths
        std::vector<std::string> pluginPaths = {
            "./plugins/",
            "../plugins/",
            std::filesystem::current_path().string() + "/plugins/",
            std::filesystem::current_path().string() + "/../bin/plugins/",
            "plugins/"
        };

        bool loaded = false;
        for (const auto& path : pluginPaths) {
            std::cout << "[System] Trying plugins directory: " << path << std::endl;
            pluginManager.setPluginsDirectory(path);
            int loadedCount = pluginManager.loadAllPlugins();
            if (loadedCount > 0) {
                loaded = true;
                break;
            }
        }

        if (!loaded) {
            std::cout << "[System] No plugins loaded. Create plugins directory and add .dll/.so files." << std::endl;
            std::cout << "[System] Expected plugin location: " << std::filesystem::current_path() << "/plugins/" << std::endl;
        }

        pluginMenuItems = pluginManager.getPluginMenuItems();
        printRegisteredTypes();

        // Show loaded plugins
        auto pluginNames = pluginManager.getLoadedPluginNames();
        if (!pluginNames.empty()) {
            std::cout << "\n[System] Loaded plugins:" << std::endl;
            for (const auto& name : pluginNames) {
                std::cout << "  - " << name << std::endl;
            }
        }
    }

    void addPet() {
        std::cout << "\n=== Add New Pet ===\n";

        auto allTypes = Animal::getRegisteredTypes();

        std::cout << "Select pet type:\n";
        for (size_t i = 0; i < allTypes.size(); ++i) {
            std::string indicator = pluginManager.isPluginType(allTypes[i]) ? " (Plugin)" : "";
            std::cout << (i + 1) << ". " << allTypes[i] << indicator << std::endl;
        }

        std::cout << "Choice: ";

        int choice;
        std::cin >> choice;

        if (choice < 1 || choice > static_cast<int>(allTypes.size())) {
            std::cout << "Invalid choice!\n";
            clearInputBuffer();
            return;
        }

        std::string selectedType = allTypes[choice - 1];
        clearInputBuffer();

        // Check if this is a plugin type
        if (pluginManager.isPluginType(selectedType)) {
            // Plugin animal - use field-based interactive creation
            auto fields = pluginManager.getFieldsForType(selectedType);

            if (fields.empty()) {
                std::cout << "Error: No field information for this plugin type!\n";
                return;
            }

            std::vector<std::pair<std::string, std::string>> fieldValues;

            std::cout << "\n=== Creating " << selectedType << " ===\n";
            for (const auto& field : fields) {
                std::cout << field.label;
                std::string input;
                std::getline(std::cin, input);
                if (input.empty() && field.required) {
                    input = field.defaultValue;
                }
                fieldValues.push_back({field.name, input});
            }

            auto animal = pluginManager.createPluginAnimal(selectedType, fieldValues);
            if (animal) {
                pets.push_back(animal);
                std::cout << "Pet added successfully!\n";
            } else {
                std::cout << "Failed to create pet!\n";
            }
        } else {
            // Built-in animal - use existing method
            createBuiltInAnimal(selectedType);
        }
    }

    void createBuiltInAnimal(const std::string& type) {
    std::string name, color, breed, waterType, cageSize, furLength;
    int age, trained, indoor, hasWheel, finCount;
    double weight, wingspan;
    int canFly;

    std::cout << "Name: ";
    std::getline(std::cin, name);
    std::cout << "Age (years): ";
    std::cin >> age;
    std::cout << "Weight (kg): ";
    std::cin >> weight;
    std::cout << "Color: ";
    std::cin >> color;

    if (type == "Dog") {
        std::string breed;
        int trained;
        std::cout << "Breed: ";
        std::cin >> breed;
        std::cout << "Is trained? (1-yes/0-no): ";
        std::cin >> trained;
        pets.push_back(std::make_shared<Dog>(name, age, weight, color, breed, trained == 1));
    }
    else if (type == "Cat") {
        int indoor;
        std::string furLength;
        std::cout << "Indoor only? (1-yes/0-no): ";
        std::cin >> indoor;
        std::cout << "Fur length (Short/Medium/Long): ";
        std::cin >> furLength;
        pets.push_back(std::make_shared<Cat>(name, age, weight, color, indoor == 1, furLength));
    }
    else if (type == "Bird") {
        double wingspan;
        int canFly;
        std::cout << "Wingspan (cm): ";
        std::cin >> wingspan;
        std::cout << "Can fly? (1-yes/0-no): ";
        std::cin >> canFly;
        pets.push_back(std::make_shared<Bird>(name, age, weight, color, wingspan, canFly == 1));
    }
    else if (type == "Fish") {
        std::string waterType;
        int finCount;
        std::cout << "Water type (Freshwater/Saltwater): ";
        std::cin >> waterType;
        std::cout << "Number of fins: ";
        std::cin >> finCount;
        pets.push_back(std::make_shared<Fish>(name, age, weight, color, waterType, finCount));
    }
    else if (type == "Hamster") {
        int hasWheel;
        std::string cageSize;
        std::cout << "Has exercise wheel? (1-yes/0-no): ";
        std::cin >> hasWheel;
        std::cout << "Cage size (Small/Medium/Large): ";
        std::cin >> cageSize;
        pets.push_back(std::make_shared<Hamster>(name, age, weight, color, hasWheel == 1, cageSize));
    }

    std::cout << "Pet added successfully!\n";
}

    void editPet() {
        if (pets.empty()) {
            std::cout << "No pets to edit!\n";
            return;
        }

        displayAllPets();
        std::cout << "Enter index to edit (0-" << pets.size() - 1 << "): ";
        int index;
        std::cin >> index;

        if (index >= 0 && index < static_cast<int>(pets.size())) {
            pets[index]->edit();
            std::cout << "Pet updated successfully!\n";
        } else {
            std::cout << "Invalid index!\n";
        }
    }

    void deletePet() {
        if (pets.empty()) {
            std::cout << "No pets to delete!\n";
            return;
        }

        displayAllPets();
        std::cout << "Enter index to delete (0-" << pets.size() - 1 << "): ";
        int index;
        std::cin >> index;

        if (index >= 0 && index < static_cast<int>(pets.size())) {
            pets.erase(pets.begin() + index);
            std::cout << "Pet deleted successfully!\n";
        } else {
            std::cout << "Invalid index!\n";
        }
    }

    void displayAllPets() const {
        if (pets.empty()) {
            std::cout << "\n=== No pets in the collection ===\n";
            return;
        }

        std::cout << "\n=== Pet Collection ===\n";
        for (size_t i = 0; i < pets.size(); ++i) {
            std::cout << "\n[" << i << "]\n";
            pets[i]->display();
            std::cout << "--------------------\n";
        }
    }

    void saveToFile() {
        std::string filename;
        std::cout << "Enter filename to save (e.g., pets.json): ";
        std::cin >> filename;

        if (serializer.saveToFile(pets, filename)) {
            std::cout << "Successfully saved " << pets.size() << " pets to " << filename << "\n";
        } else {
            std::cout << "Failed to save to file!\n";
        }
    }

    void loadFromFile() {
        std::string filename;
        std::cout << "Enter filename to load (e.g., pets.json): ";
        std::cin >> filename;

        auto loadedPets = serializer.loadFromFile(filename);
        if (loadedPets) {
            pets = std::move(*loadedPets);
            std::cout << "Successfully loaded " << pets.size() << " pets from " << filename << "\n";
        } else {
            std::cout << "Failed to load from file!\n";
        }
    }

    void showPlugins() {
        auto pluginNames = pluginManager.getLoadedPluginNames();
        auto pluginTypes = pluginManager.getPluginAnimalTypes();

        std::cout << "\n=== Loaded Plugins ===\n";
        if (pluginNames.empty()) {
            std::cout << "No plugins loaded.\n";
            std::cout << "Place .so/.dll files in ./plugins/ directory\n";
        } else {
            for (const auto& name : pluginNames) {
                std::cout << "  Plugin: " << name << std::endl;
            }
            std::cout << "\nPlugin animal types:\n";
            for (const auto& type : pluginTypes) {
                std::cout << "  - " << type << std::endl;
            }
        }
    }
};

void showMenu() {
    std::cout << "        PET MANAGEMENT SYSTEM (PLUGIN READY)     \n";
    std::cout << "  1. Add new pet                                 \n";
    std::cout << "  2. Edit pet                                    \n";
    std::cout << "  3. Delete pet                                  \n";
    std::cout << "  4. Display all pets                            \n";
    std::cout << "  5. Save to JSON file                           \n";
    std::cout << "  6. Load from JSON file                         \n";
    std::cout << "  7. Show loaded plugins                         \n";
    std::cout << "  8. Exit                                        \n";
    std::cout << "Choice: ";
}

int main() {
    PetManager manager;
    int choice;

    std::cout << "\n🐾 Welcome to Pet Management System with Plugin Support! 🐾\n";

    while (true) {
        showMenu();
        std::cin >> choice;

        switch (choice) {
            case 1: manager.addPet(); break;
            case 2: manager.editPet(); break;
            case 3: manager.deletePet(); break;
            case 4: manager.displayAllPets(); break;
            case 5: manager.saveToFile(); break;
            case 6: manager.loadFromFile(); break;
            case 7: manager.showPlugins(); break;
            case 8:
                std::cout << "\nGoodbye! Thanks for using Pet Management System! 🐾\n";
                return 0;
            default:
                std::cout << "Invalid choice! Please enter 1-8.\n";
        }
    }

    return 0;
}