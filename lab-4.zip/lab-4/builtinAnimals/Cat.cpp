#include "Cat.h"
#include "..\core\RegisterHelper.h"
#include <iostream>

// Automatic registration - no if-else needed!
static RegisterHelper<Cat> registryCat("Cat");

Cat::Cat(const std::string& name, int age, double weight, const std::string& color,
         bool isIndoor, const std::string& furLength)
    : Animal(name, age, weight, color), isIndoor(isIndoor), furLength(furLength) {}

Cat::Cat(const json& j) {
    fromJson(j);
}

json Cat::toJson() const {
    json j;
    j["type"] = "Cat";
    j["name"] = name;
    j["age"] = age;
    j["weight"] = weight;
    j["color"] = color;
    j["isIndoor"] = isIndoor;
    j["furLength"] = furLength;
    return j;
}

void Cat::fromJson(const json& j) {
    name = j.value("name", "");
    age = j.value("age", 0);
    weight = j.value("weight", 0.0);
    color = j.value("color", "");
    isIndoor = j.value("isIndoor", true);
    furLength = j.value("furLength", "Short");
}

void Cat::display() const {
    std::cout << " CAT\n";
    std::cout << "  Name: " << name << "\n";
    std::cout << "  Age: " << age << " years\n";
    std::cout << "  Weight: " << weight << " kg\n";
    std::cout << "  Color: " << color << "\n";
    std::cout << "  Indoor: " << (isIndoor ? "Yes" : "No") << "\n";
    std::cout << "  Fur Length: " << furLength << "\n";
}

void Cat::edit() {
    std::cout << "\nEditing Cat\n";
    std::cout << "Name (" << name << "): ";
    std::string input;
    std::cin.ignore();
    std::getline(std::cin, input);
    if (!input.empty()) name = input;
    
    std::cout << "Age (" << age << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) age = std::stoi(input);
    
    std::cout << "Weight (" << weight << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) weight = std::stod(input);
    
    std::cout << "Color (" << color << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) color = input;
    
    std::cout << "Indoor only? (1-yes/0-no) (" << isIndoor << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) isIndoor = (input == "1");
    
    std::cout << "Fur Length (Short/Medium/Long) (" << furLength << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) furLength = input;
}