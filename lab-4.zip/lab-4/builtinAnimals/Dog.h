#ifndef DOG_H
#define DOG_H

#include "..\core\Animal.h"

/**
 * Dog class - inherits from Animal
 * Adds breed and trained status specific to dogs
 */
class Dog : public Animal {
private:
    std::string breed;     // Dog breed (e.g., Labrador, German Shepherd)
    bool isTrained;        // Whether the dog is trained

public:
    Dog(const std::string& name = "", int age = 0, double weight = 0.0,
        const std::string& color = "", const std::string& breed = "", bool isTrained = false);
    Dog(const json& j);    // Constructor for deserialization

    // Getters
    std::string getBreed() const { return breed; }
    bool getIsTrained() const { return isTrained; }

    // Setters
    void setBreed(const std::string& b) { breed = b; }
    void setIsTrained(bool trained) { isTrained = trained; }

    // Override virtual methods
    json toJson() const override;
    void fromJson(const json& j) override;
    void display() const override;
    std::string getType() const override { return "Dog"; }
    void edit() override;
};

#endif