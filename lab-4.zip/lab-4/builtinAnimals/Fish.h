#ifndef FISH_H
#define FISH_H

#include "..\core\Animal.h"

/**
 * Fish class - inherits from Animal
 * Adds water type and fin count
 */
class Fish : public Animal {
private:
    std::string waterType; // Freshwater or Saltwater
    int finCount;          // Number of fins

public:
    Fish(const std::string& name = "", int age = 0, double weight = 0.0,
         const std::string& color = "", const std::string& waterType = "Freshwater", int finCount = 0);
    Fish(const json& j);
    
    // Getters
    std::string getWaterType() const { return waterType; }
    int getFinCount() const { return finCount; }

    // Setters
    void setWaterType(const std::string& wt) { waterType = wt; }
    void setFinCount(int fc) { finCount = fc; }

    // Override virtual methods
    json toJson() const override;
    void fromJson(const json& j) override;
    void display() const override;
    std::string getType() const override { return "Fish"; }
    void edit() override;
};

#endif