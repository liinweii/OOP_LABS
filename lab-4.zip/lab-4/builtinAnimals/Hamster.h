#ifndef HAMSTER_H
#define HAMSTER_H

#include "..\core\Animal.h"

/**
 * Hamster class - inherits from Animal
 * Adds wheel and cage size
 */
class Hamster : public Animal {
private:
    bool hasWheel;         // Whether hamster has exercise wheel
    std::string cageSize;  // Small, Medium, Large

public:
    Hamster(const std::string& name = "", int age = 0, double weight = 0.0,
            const std::string& color = "", bool hasWheel = true, const std::string& cageSize = "Medium");
    Hamster(const json& j);
    
    // Getters
    bool getHasWheel() const { return hasWheel; }
    std::string getCageSize() const { return cageSize; }

    // Setters
    void setHasWheel(bool wheel) { hasWheel = wheel; }
    void setCageSize(const std::string& size) { cageSize = size; }

    // Override virtual methods
    json toJson() const override;
    void fromJson(const json& j) override;
    void display() const override;
    std::string getType() const override { return "Hamster"; }
    void edit() override;
};

#endif