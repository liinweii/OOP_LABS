#include "Hamster.h"
#include "..\core\RegisterHelper.h"
#include <iostream>

// Automatic registration - no if-else needed!
static RegisterHelper<Hamster> registryHamster("Hamster");

Hamster::Hamster(const std::string& name, int age, double weight, const std::string& color,
                 bool hasWheel, const std::string& cageSize)
    : Animal(name, age, weight, color), hasWheel(hasWheel), cageSize(cageSize) {}

Hamster::Hamster(const json& j) {
    fromJson(j);
}

json Hamster::toJson() const {
    json j;
    j["type"] = "Hamster";
    j["name"] = name;
    j["age"] = age;
    j["weight"] = weight;
    j["color"] = color;
    j["hasWheel"] = hasWheel;
    j["cageSize"] = cageSize;
    return j;
}

void Hamster::fromJson(const json& j) {
    name = j.value("name", "");
    age = j.value("age", 0);
    weight = j.value("weight", 0.0);
    color = j.value("color", "");
    hasWheel = j.value("hasWheel", true);
    cageSize = j.value("cageSize", "Medium");
}

void Hamster::display() const {
    std::cout << " HAMSTER\n";
    std::cout << "  Name: " << name << "\n";
    std::cout << "  Age: " << age << " years\n";
    std::cout << "  Weight: " << weight << " kg\n";
    std::cout << "  Color: " << color << "\n";
    std::cout << "  Has Wheel: " << (hasWheel ? "Yes" : "No") << "\n";
    std::cout << "  Cage Size: " << cageSize << "\n";
}

void Hamster::edit() {
    std::cout << "\nEditing Hamster\n";
    std::cout << "Name (" << name << "): ";
    std::string input;
    std::cin.ignore();
    std::getline(std::cin, input);
    if (!input.empty()) name = input;
    
    std::cout << "Age (" << age << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) age = std::stoi(input);
    
    std::cout << "Weight (" << weight << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) weight = std::stod(input);
    
    std::cout << "Color (" << color << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) color = input;
    
    std::cout << "Has Exercise Wheel? (1-yes/0-no) (" << hasWheel << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) hasWheel = (input == "1");
    
    std::cout << "Cage Size (Small/Medium/Large) (" << cageSize << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) cageSize = input;
}