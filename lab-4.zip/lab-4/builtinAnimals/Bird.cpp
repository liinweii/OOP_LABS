#include "Bird.h"
#include "..\core\RegisterHelper.h"
#include <iostream>
#include "Animal.h"

// Automatic registration - no if-else needed!
static RegisterHelper<Bird> registryBird("Bird");

Bird::Bird(const std::string& name, int age, double weight, const std::string& color,
           double wingspan, bool canFly)
    : Animal(name, age, weight, color), wingspan(wingspan), canFly(canFly) {}

Bird::Bird(const json& j) {
    fromJson(j);
}

json Bird::toJson() const {
    json j;
    j["type"] = "Bird";
    j["name"] = name;
    j["age"] = age;
    j["weight"] = weight;
    j["color"] = color;
    j["wingspan"] = wingspan;
    j["canFly"] = canFly;
    return j;
}

void Bird::fromJson(const json& j) {
    name = j.value("name", "");
    age = j.value("age", 0);
    weight = j.value("weight", 0.0);
    color = j.value("color", "");
    wingspan = j.value("wingspan", 0.0);
    canFly = j.value("canFly", true);
}

void Bird::display() const {
    std::cout << " BIRD\n";
    std::cout << "  Name: " << name << "\n";
    std::cout << "  Age: " << age << " years\n";
    std::cout << "  Weight: " << weight << " kg\n";
    std::cout << "  Color: " << color << "\n";
    std::cout << "  Wingspan: " << wingspan << " cm\n";
    std::cout << "  Can Fly: " << (canFly ? "Yes" : "No") << "\n";
}

void Bird::edit() {
    std::cout << "\nEditing Bird\n";
    std::cout << "Name (" << name << "): ";
    std::string input;
    std::cin.ignore();
    std::getline(std::cin, input);
    if (!input.empty()) name = input;
    
    std::cout << "Age (" << age << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) age = std::stoi(input);
    
    std::cout << "Weight (" << weight << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) weight = std::stod(input);
    
    std::cout << "Color (" << color << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) color = input;
    
    std::cout << "Wingspan (" << wingspan << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) wingspan = std::stod(input);
    
    std::cout << "Can Fly? (1-yes/0-no) (" << canFly << "): ";
    std::getline(std::cin, input);
    if (!input.empty()) canFly = (input == "1");
}